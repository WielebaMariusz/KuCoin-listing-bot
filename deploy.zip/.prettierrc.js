module.exports = {
  bracketSpacing: true,
  jsxBracketSameLine: true,
  singleQuote: true,
  trailingComma: 'none',
  tabWidth: 2,
  printWidth: 100,
  arrowParens: 'avoid'
};
